zypper update
zypper install mono-complete
zypper install screen
mkdir /etc/nat123
chmod 777 /etc/nat123
cp ./source/program/* /etc/nat123