yum update
yum install mono-complete
yum install screen
mkdir /etc/nat123
chmod 777 /etc/nat123
cp ./source/program/* /etc/nat123
