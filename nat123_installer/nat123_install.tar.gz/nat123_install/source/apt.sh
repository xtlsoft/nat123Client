apt-get update
apt-get install mono-complete
apt-get install screen
mkdir /etc/nat123
chmod 777 /etc/nat123
cp ./source/program/* /etc/nat123
