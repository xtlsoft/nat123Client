cd /etc/nat123
./nat123Client
